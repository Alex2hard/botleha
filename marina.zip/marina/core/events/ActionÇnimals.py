from core.base import Event, IncomingMessage
from core import Pythogram


animals = [
    dict(animal="лев", href="https://laplaya-rus.ru/wp-content/uploads/3/b/8/3b8f9db88021b4fb57ea77f0279783d3.jpeg"),
    dict(animal="тигр", href="https://krasivosti.pro/uploads/posts/2021-11/1637797797_4-krasivosti-pro-p-afrikanskii-tigr-zhivotnie-krasivo-foto-5.jpg"),
    dict(animal="слон", href="https://kipmu.ru/wp-content/uploads/svnsl2.jpg"),
    dict(animal="коала", href="https://sport-dog.ru/wp-content/uploads/4/8/0/4808fe5783e4f2892f2efe62a0800817.jpeg"),
    dict(animal="волк", href="https://kadet39.ru/wp-content/uploads/1/7/6/176f085964629d6c222d8306bbe1b965.jpeg"),
    dict(animal="лиса", href="http://funart.pro/uploads/posts/2021-04/1618259756_8-p-dovolnaya-lisa-zhivotnie-krasivo-foto-8.jpg"),
    dict(animal="медведь", href="https://webpulse.imgsmail.ru/imgpreview?mb=webpulse&key=pulse_cabinet-image-b9c3d3f8-31a8-42be-981c-24605748ada2"),
]


class ActionCar(Event):
    def __init__(self, sender: Pythogram):
        self.__sender = sender

    def check(self, message: IncomingMessage, *args, **kwargs) -> bool:
        text = message.text.strip().lower()
        return text in ["лев", "тигр", "слон", "коала", "волк", "лиса", "медведь"]

    def action(self, message: IncomingMessage, *args, **kwargs):
        text = message.text
        for animal in animals:
            if text == animal.get("an"):
                self.__sender.photo.send(
                    file=animal.get("href"),
                    chat=message.chat
                )


