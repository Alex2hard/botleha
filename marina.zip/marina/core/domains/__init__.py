from .Webhook import Webhook
from .User import User
from .Chat import Chat
from .Photo import Photo

__all__ = ['Webhook', 'User', 'Chat', 'Photo']
